#ifndef _BITS_SOCKET_H
#define _BITS_SOCKET_H

typedef uint32_t socklen_t;
typedef uint32_t sa_family_t;

#endif /* ! _BITS_SOCKET_H */
