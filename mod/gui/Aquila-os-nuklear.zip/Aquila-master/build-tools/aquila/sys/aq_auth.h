#ifndef _AQ_AUTH_H
#define _AQ_AUTH_H

#include <sys/types.h>

int aquila_auth(uid_t uid, const char *path);

#endif
