#ifndef _MOUNT_H
#define _MOUNT_H

int mount(const char *type, const char *dir, int flags, void *data);

#endif
