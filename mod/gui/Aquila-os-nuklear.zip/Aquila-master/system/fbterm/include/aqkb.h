#ifndef _KBD_H
#define _KBD_H

void *aqkb_thread(void *arg);

#endif /* ! _KBD_H */
