#include <fs/posix.h>
#include <bits/fcntl.h>
#include <fs/stat.h>
#include <sys/sched.h>

int posix_file_open(struct file *file)
{
    return 0;
}
