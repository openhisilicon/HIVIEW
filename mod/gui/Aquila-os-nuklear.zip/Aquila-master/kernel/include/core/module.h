#ifndef _MODULE_H
#define _MODULE_H

int modules_init();

#endif
