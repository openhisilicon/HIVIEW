#ifndef _THREAD_H
#define _THREAD_H

#include <core/system.h>

typedef struct thread thread_t;
typedef enum proc_state state_t;
typedef pid_t tid_t;


#endif
