#ifndef _CONSOLE_H
#define _CONSOLE_H

#include <core/system.h>
#include <dev/dev.h>

extern struct dev console;

#endif  /* !_CONSOLE_H */
