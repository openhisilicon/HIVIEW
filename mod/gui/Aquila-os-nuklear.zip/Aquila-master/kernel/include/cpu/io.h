#ifndef _IO_H
#define _IO_H

#include <core/system.h>

/* Overrided with arch specific header */

#endif /* _IO_H */
