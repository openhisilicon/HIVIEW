#ifndef _CPU_H
#define _CPU_H

/* Include arch specific CPU header */
#include <cpu/_cpu.h>

#endif /* _CPU_H */
