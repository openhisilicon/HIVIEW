#ifndef _TMPFS_H
#define _TMPFS_H

#include <fs/vfs.h>

extern struct fs tmpfs;

#endif /* !_DEVFS_H */
