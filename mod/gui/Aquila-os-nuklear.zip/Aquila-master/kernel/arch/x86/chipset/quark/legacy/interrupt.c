#include <core/system.h>

void quark_interrupt_decoder_setup()
{

}
