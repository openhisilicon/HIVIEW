#ifndef _QUARK_LEGACY_BRIDGE_H
#define _QUARK_LEGACY_BRIDGE_H

#include <dev/pci.h>

extern struct pci_dev qrk_leg_brdg;
void quark_legacy_bridge_setup();

#endif /* ! _QUARK_LEGACY_BRIDGE_H */
