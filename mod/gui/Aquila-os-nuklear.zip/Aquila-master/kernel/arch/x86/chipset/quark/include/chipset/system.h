#ifndef _QUARK_CHIPSET
#define _QUARK_CHIPSET

void quark_legacy_bridge_setup();

#endif /* ! _QUARK_CHIPSET */
