#ifndef _QUARK_ROOT_COMPLEX_H
#define _QUARK_ROOT_COMPLEX_H

void quark_root_complex_io_fabric_route(int intr_pin, int irq);
void quark_root_complex_init();

#endif /* ! _QUARK_ROOT_COMPLEX_H */
