#ifndef _X86_SYSCALL_H
#define _X86_SYSCALL_H


#endif /* ! _X86_SYSCALL_H */
