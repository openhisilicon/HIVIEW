#ifndef _X86_PIT_H
#define _X86_PIT_H

#include <core/system.h>

void pit_setup(uint32_t freq);

#endif /* ! _X86_PIT_H */
