#ifndef _MEMDEV_H
#define _MEMDEV_H

#include <dev/dev.h>

extern struct dev nulldev;
//extern struct dev portdev;
extern struct dev zerodev;

#endif /* ! _MEMDEV_H */
