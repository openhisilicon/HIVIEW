# linux_frame_buffer
LittlevGL configured to work with /dev/fb0 on Linux
